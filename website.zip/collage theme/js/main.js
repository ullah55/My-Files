(function ($) {
	
	 $(window).load(function() {
        $('#slider').nivoSlider();
    });
	
	
}(jQuery));	