<?php get_header();?>
		
		<div class="main_content"> 
			<div class="left_side"> 
				
			</div>
			<div class="content">
					<?php while ( have_posts() ) : the_post();?>
						<div class="page_content"> 
							<h1><?php the_title();?></h1>
							<?php the_content();?>
						</div>
					<?php endwhile;?>
			</div>
			<div class="right_side"></div>
		</div>
	<?php get_footer();?>