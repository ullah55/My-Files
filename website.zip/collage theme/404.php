<?php get_header();?>
		
		<div class="main_content"> 
			<div class="left_side"> 
				
			</div>
			<div class="content">
					<div class="page-header">
					<h1 class="page-title"><?php _e( 'Oops! That page can&rsquo;t be found.', 'twentyfifteen' ); ?></h1>
				</div><!-- .page-header -->

				<div class="page-content">
					<p><?php _e( 'It looks like nothing was found at this location. Maybe try a search?', 'twentyfifteen' ); ?></p>

					<?php get_search_form(); ?>
				</div>
			</div>
			<div class="right_side"></div>
		</div>
	<?php get_footer();?>