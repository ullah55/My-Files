<?php 
/*
Template Name:Home Page
*/

get_header();?>
		<div class="slider_top "> 
		<?php $sliderr = new WP_Query(
			array(
				'post_type'=>'slider',
				'post_per_page'=>'4'
			));?>
			 <div id="slider" class="nivoSlider">
			<?php while($sliderr->have_posts()):$sliderr->the_post();?>
           
				<?php the_post_thumbnail();?>
            
			<?php endwhile;?>
			</div>
		</div>
		<div class="main_content fix"> 
			<div class="left_side "> 
				
				<div class="left_drop"> 
				<h1>পাতাসমূহ</h1>
					<ul> 
						<?php wp_nav_menu(array('theme_location'=>'amar_menu',));?>
					</ul>
				</div>
				<div class="imp_link"> 
					<ul>
						<?php dynamic_sidebar('sidebar-1'); ?>
					</ul>
				</div>
			</div>
			<div class="content">
					<?php while ( have_posts() ) : the_post();?>
						<div class="page_content"> 
							<h1><?php the_title();?></h1>
							<?php the_content();?>
						</div>
					<?php endwhile;?>
			</div>
			<div class="right_side"> 
				<div class="right_one_notice"> 
					<h1>নোটিশ বোর্ড</h1>
					<marquee direction="up"> 
						<?php
							$latest_post = new WP_Query("post_type=post");
							if($latest_post->have_posts()) :
						?>
						<div class="boxBar">
							<?php
								while($latest_post->have_posts()):
									$latest_post->the_post();
							?>
							<h1 class="boxedHeader">
								<a href="<?php the_permalink();?>"><?php the_title() ?></a>
							</h1>
							<?php endwhile ?>
						</div>
						<?php endif ?>
					</marquee>
				</div>
				<div class="right_one_notice"> 
					<?php dynamic_sidebar('sidebar-2'); ?>
				</div>
			</div>
		</div>
	<?php get_footer();?>