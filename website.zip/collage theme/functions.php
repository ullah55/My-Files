<?php 

add_theme_support('title-tag');

function all_need(){
	register_nav_menu('main_menu','Main Menu');
	register_nav_menu('amar_menu','Left Menu');
}
add_action('after_setup_theme','all_need');


function hasan_imp_link(){ 
	wp_register_style('nivo',get_template_directory_uri().'/css/nivo-slider.css');
	
	wp_enqueue_style( 'my-style', get_stylesheet_uri() );
	
	wp_register_script('slider',get_template_directory_uri().'/js/jquery.nivo.slider.js');
	wp_register_script('min2',get_template_directory_uri().'/js/main.js');
	
	wp_enqueue_style('nivo');
	wp_enqueue_script('jquery');
	wp_enqueue_script('min2');
	wp_enqueue_script('slider');
}
add_action('wp_enqueue_scripts','hasan_imp_link');

function customize_hasan($hasan){ 
		
		$hasan->add_section('logo_one',array( 
			'title'=>'General Section',
			'priority'=>10
		)); 
		
		$hasan->add_setting('logo',array( 
			'default'=>'Header Banner',
			'transport'=>'refresh'
		
		));
		
		$hasan->add_control( 
			new WP_Customize_Image_Control($hasan,'logo',array( 
				'section'=>'logo_one',
			'label'=>'Upload Logo',
			'settings'=>'logo'
			
			))
		);
		
		
		//CopyRight
		
		$hasan->add_setting('text_footer',array( 
			'default'=>'Text Here',
			'transport'=>'refresh'
		
		));
		
		$hasan->add_control('text_footer',array( 
			'section'=>'logo_one',
			'label'=>'Copy Right Text Here',
			'type'=>'text'
			
		
		));	
		
	
}
add_action('customize_register','customize_hasan');








//Image Registration
	add_theme_support('post-thumbnails',array('post','slider'));
	add_image_size('sldimg');

function all_custompost_registration(){
	register_post_type('slider',array( 
			'labels'=>array(
				'name'=>'Slider'
			),
			'public'=>true,
			'supports'=>array('thumbnail')
	));
	
	register_post_type('wcnote',array( 
			'labels'=>array(
				'name'=>'WelCome Note'
			),
			'public'=>true,
			'supports'=>array('title','editor','thumbnail','custom-fields')
	));
}
add_action('init','all_custompost_registration');


			
				
		
			
			
			function hasan_widgets_init() {
					register_sidebar( array(
						'name'          => __( 'Features Widget Left', 'hasan' ),
						'id'            => 'sidebar-1',
						'description'   => __( 'Add widgets here to appear in your sidebar.', 'Collage Theme' ),
						'before_widget' => '<ul><li>',
						'after_widget'  => '</li></ul>',
						'before_title'  => '<h1>',
						'after_title'   => '</h1>',
					) );
					
					register_sidebar( array(
						'name'          => __( 'Features Widget Right', 'hasan' ),
						'id'            => 'sidebar-2',
						'description'   => __( 'Add widgets here to appear in your sidebar.', 'Collage Theme' ),
						'before_widget' => '',
						'after_widget'  => '',
						'before_title'  => '<h1>',
						'after_title'   => '</h1>',
					) );
					
				
				}
				add_action( 'widgets_init', 'hasan_widgets_init' );
?>