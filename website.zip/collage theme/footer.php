	<div class="footer"> 
			<h1>Copyright &copy;<?php echo get_theme_mod('text_footer');?></h1>
		</div>
	</div>
  
	<?php wp_footer();?>
</body>
</html>



