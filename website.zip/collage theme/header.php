<!DOCTYPE HTML>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
</head>
<?php wp_head();?>
<body>
	<div class="wrapper"> 
		<div class="header"> 
			<img src="<?php echo get_theme_mod('logo');?>" alt="" />
		</div>
		<div class="menu_top"> 
			<ul> 
				<?php wp_nav_menu(array('theme_location'=>'main_menu',));?>
			</ul>
		</div>