
	
	$(document).ready(function(){

    var slider = $('.slider_one').bxSlider({
        minSlides: 1,
            maxSlides: 1,
            slideWidth: 360,
            slideMargin: 5,
            pager:true,
			nextSelector: '#slider-next',
            prevSelector: '#slider-prev',
            nextText: '<i class="fa fa-long-arrow-up"></i>',
            prevText: '<i class="fa fa-long-arrow-down"></i>'
    });
 
    

    
	

});

$(document).ready(function(){

 var slider = $('.slider_two').bxSlider({
        minSlides: 1,
            maxSlides: 1,
            slideWidth: 360,
            slideMargin: 5,
            pager:true,
			nextSelector: '#slider-nex',
            prevSelector: '#slider-pre',
            nextText: '<i class="fa fa-long-arrow-left"></i>',
            prevText: '<i class="fa fa-long-arrow-right"></i>'
    });
});